﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace sqlDiplome
{
    public partial class Sotrydniki : Form
    {
        string[] str = new string[5];
        private string _userRole;
        public Sotrydniki(string p1, string p2, string p3, string p4, string p5, string userRole)
        {
            InitializeComponent();
            str[0] = p1;
            str[1] = p2;
            str[2] = p3;
            str[3] = p4;
            str[4] = p5;
            _userRole = userRole;
            UIchoiceRole();
        }
        private void UIchoiceRole()
        {
            switch (_userRole)
            {
                case "Администратор":

                    break;

                case "Начальник ОТК":

                    break;

                case "Работник ОТК":
                    button2.Visible = false;
                    break;

                default:
                    MessageBox.Show("Неизвестная роль пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) 
            || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(comboBox1.Text))
            {
                MessageBox.Show("Поля не должны быть пустыми");
                return;
            }

            try
            {

                string query = $"INSERT INTO Sotrydniki (ID_sotryd, FIO, Telephone, Email, Dolwnost)" +
                $"VALUES(@value1, @value2, @value3, @value4, @value5)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@value1", textBox1.Text);
                command.Parameters.AddWithValue("@value2", textBox2.Text);
                command.Parameters.AddWithValue("@value3", textBox3.Text);
                command.Parameters.AddWithValue("@value4", textBox4.Text);
                command.Parameters.AddWithValue("@value5", comboBox1.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные сохранены");
            }
            catch
            {

                DialogResult result = MessageBox.Show("Запись с таким кодом уже есть. Перезаписать данные?", "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.None,
                    MessageBoxDefaultButton.Button1);

                if (result == DialogResult.Yes)
                {
                    string query = $"UPDATE Sotrydniki SET FIO = @value2, Telephone = @value3, Email = @value4, Dolwnost = @value5" +
                    $" WHERE ID_sotryd = @value1";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@value1", textBox1.Text);
                    command.Parameters.AddWithValue("@value2", textBox2.Text);
                    command.Parameters.AddWithValue("@value3", textBox3.Text);
                    command.Parameters.AddWithValue("@value4", textBox4.Text);
                    command.Parameters.AddWithValue("@value5", comboBox1.Text);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные изменены");
                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();


            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                if (!String.IsNullOrEmpty(textBox1.Text))
                {
                    try
                    {
                        string query = $"DELETE FROM Sotrydniki WHERE ID_sotryd = {textBox1.Text}";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные удалены");

                    }
                    catch
                    {

                    }
                }
                else { MessageBox.Show("Данные не изменились"); }

            }
            else { MessageBox.Show("Введите id sotryd"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                try
                {
                    string query = $"SELECT * FROM Sotrydniki WHERE ID_sotryd = {textBox1.Text}";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        textBox1.Text = reader[0].ToString();
                        textBox2.Text = reader[1].ToString();
                        textBox3.Text = reader[2].ToString();
                        textBox4.Text = reader[3].ToString();
                        comboBox1.Text = reader[4].ToString();
                    }
                    else { MessageBox.Show("Данные не найдены"); }

                }
                catch
                {

                }

            }
            else { MessageBox.Show("Введите id oboryd"); }
        }

        private void Sotrydniki_Shown(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            comboBox1.Items.Add("Администратор");
            comboBox1.Items.Add("Работник ОТК");
            comboBox1.Items.Add("Начальник ОТК");
            if (!String.IsNullOrEmpty(str[0]))
            {

                textBox1.Text = str[0];
                textBox2.Text = str[1];
                textBox3.Text = str[2];
                textBox4.Text = str[3];
                comboBox1.Text = str[4];    

            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && e.KeyChar != ' ' && (e.KeyChar < 'А' || e.KeyChar > 'я') && e.KeyChar != 'ё' && e.KeyChar != 'Ё')
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && e.KeyChar != ' ' && (e.KeyChar < 'A' || e.KeyChar > 'z'))
            {
                e.Handled = true;
            }
        }
    }
}
