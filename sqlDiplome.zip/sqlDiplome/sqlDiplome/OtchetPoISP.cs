﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Excel = Microsoft.Office.Interop.Excel;



namespace sqlDiplome
{
    public partial class OtchetPoISP : Form
    {
        public OtchetPoISP()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            try
            {

                string query = $@"SELECT 
    O.Nazvanie AS Name_Oboryd,          
    O.SerialNumber,                       
    O.Date_privoz,                        
    O.Garantia,                           
    S.FIO AS FIO_Sotryd,               
    S.Dolwnost AS Sotryd_Dolwnost,      
    T.Name_T AS test_name,                
    I.Date_ispitanie,                     
    I.Result_ISP                         
FROM 
    Ispitanie I
JOIN 
    Oboryd O ON I.ID_oboryd = O.ID_oboryd  
JOIN 
    Sotrydniki S ON I.ID_sotryd = S.ID_sotryd  
JOIN 
    Vibor V ON I.ID_ispitanie = V.ID_ispitanie  
JOIN 
    Testu T ON V.ID_test = T.ID_test; ";

                SqlDataAdapter command = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();
                command.Fill(table);
                dataGridView1.DataSource = table;
                button2.Visible = true;
            }
            catch
            {
                MessageBox.Show("Ошибка запроса");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = null;
            Excel.Worksheet xlSheet = null;
            Excel.Range xlSheetRange = null;

            try
            {
                xlApp = new Excel.Application();
                xlApp.Visible = false;

                Excel.Workbook xlWorkbook = xlApp.Workbooks.Add(Type.Missing);
                xlSheet = (Excel.Worksheet)xlWorkbook.Sheets[1];
                xlSheet.Name = "Данные";

                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    xlSheet.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
                }

                for (int rowInd = 0; rowInd < dataGridView1.Rows.Count; rowInd++)
                {
                    if (dataGridView1.Rows[rowInd].IsNewRow) continue;

                    for (int collInd = 0; collInd < dataGridView1.Columns.Count; collInd++)
                    {
                        object cellValue = dataGridView1.Rows[rowInd].Cells[collInd].Value;
                        string columnName = dataGridView1.Columns[collInd].HeaderText;
                        if (columnName == "Date_privoz" || columnName == "Date_ispitanie")
                        {
                            if (cellValue != null && DateTime.TryParse(cellValue.ToString(), out DateTime dateValue))
                            {
                                xlSheet.Cells[rowInd + 2, collInd + 1] = dateValue.ToString("dd.MM.yyyy");
                            }
                            else
                            {
                                xlSheet.Cells[rowInd + 2, collInd + 1] = cellValue?.ToString();
                            }
                        }
                        else
                        {
                            xlSheet.Cells[rowInd + 2, collInd + 1] = cellValue?.ToString();
                        }
                    }
                }
                xlSheetRange = xlSheet.UsedRange;
                xlSheetRange.Columns.ColumnWidth = 25;

                xlSheetRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                xlSheetRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range secondColumnRange = xlSheet.Range[xlSheet.Cells[2, 2], xlSheet.Cells[dataGridView1.Rows.Count + 1, 2]];
                secondColumnRange.NumberFormat = "0,00"; 

                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    string columnName = dataGridView1.Columns[i].HeaderText;
                    if (columnName == "Date_privoz" || columnName == "Date_ispitanie")
                    {
                        Excel.Range dateColumnRange = xlSheet.Range[xlSheet.Cells[2, i + 1], xlSheet.Cells[dataGridView1.Rows.Count + 1, i + 1]];
                        dateColumnRange.NumberFormat = "dd.MM.yyyy";
                    }
                }

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = "Отчет_по_испытаниям.xlsx"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    xlWorkbook.SaveAs(saveFileDialog.FileName);
                    MessageBox.Show("Отчет сохранен", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при формирование отчета" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (xlApp != null)
                {

                    xlApp.Quit();
                    releaseObject(xlSheetRange);
                    releaseObject(xlSheet);
                    releaseObject(xlApp);
                }
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Ошибка при освобождении ресурсов: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
