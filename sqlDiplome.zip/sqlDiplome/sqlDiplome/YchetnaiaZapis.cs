﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using Microsoft.Office.Interop.Excel;

namespace sqlDiplome
{
    public partial class YchetnaiaZapis : Form
    {
        string[] str = new string[5];
        private string _userRole;
        public YchetnaiaZapis(string p1, string p2, string p3, string userRole)
        {
            InitializeComponent();
            str[0] = p1;
            str[1] = p2;
            str[2] = p3;
            _userRole = userRole;
            UIchoiceRole();
        }
        private void UIchoiceRole()
        {
            switch (_userRole)
            {
                case "Администратор":

                    break;

                case "Начальник ОТК":

                    break;

                case "Работник ОТК":
                    break;

                default:
                    MessageBox.Show("Неизвестная роль пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        public static string HashPassword(string password)
        {
            using (var md5 = MD5.Create())
            {
                var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(password));

                return Convert.ToBase64String(hash);
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(comboBox.Text))
            {
                MessageBox.Show("Поля не должны быть пустыми");
                return;
            }

            try
            {
                int roleID = NameRoleIzID(comboBox.Text);

                string query = $"INSERT INTO [User] (Users, Password, LvlDostyp)" +
                               $"VALUES(@value1, @value2, @value3)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@value1", textBox1.Text);
                command.Parameters.AddWithValue("@value2", HashPassword(textBox2.Text));
                command.Parameters.AddWithValue("@value3", roleID);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные сохранены");
            }
            catch
            {
                DialogResult result = MessageBox.Show("Запись с таким кодом уже есть. Перезаписать данные?", "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.None,
                    MessageBoxDefaultButton.Button1);

                if (result == DialogResult.Yes)
                {
                    int roleID = NameRoleIzID(comboBox.Text);

                    string query = $"UPDATE [User] SET Password = @value2, LvlDostyp = @value3 " +
                                   $" WHERE Users = @value1";
                    SqlCommand command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@value1", textBox1.Text);
                    command.Parameters.AddWithValue("@value2", HashPassword(textBox2.Text));
                    command.Parameters.AddWithValue("@value3", roleID);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные изменены");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();


            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                if (!String.IsNullOrEmpty(textBox1.Text))
                {
                    try
                    {
                        string query = $"DELETE FROM [User] WHERE Users = '{textBox1.Text}'";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные удалены");

                    }
                    catch
                    {

                    }
                }
                else { MessageBox.Show("Данные не изменились"); }

            }
            else { MessageBox.Show("Введите Users"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                try
                {
                    string query = $"SELECT * FROM [User] WHERE Users = '{textBox1.Text}'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        textBox1.Text = reader[0].ToString();
                        textBox2.Text = reader[1].ToString();

                        int roleID = Convert.ToInt32(reader[2].ToString());
                        comboBox.Text = VozvratRole(roleID);
                    }
                    else { MessageBox.Show("Данные не найдены"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при поиске: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else { MessageBox.Show("Введите Users"); }
        }

        private void YchetnaiaZapis_Shown(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();
            textBox1.Clear();
            textBox2.Clear();

            comboBox.Items.Add("Администратор");
            comboBox.Items.Add("Начальник ОТК");
            comboBox.Items.Add("Работник ОТК");

            if (!String.IsNullOrEmpty(str[0]))
            {
                textBox1.Text = str[0];
                textBox2.Text = str[1];
                comboBox.Text = str[2];
            }
        }

        private int NameRoleIzID(string roleName)
        {
            switch (roleName)
            {
                case "Администратор":
                    return 1;
                case "Начальник ОТК":
                    return 2;
                case "Работник ОТК":
                    return 3;
                default:
                    throw new ArgumentException("Неизвестная роль пользователя");
            }
        }

        private string VozvratRole(int roleId)
        {
            switch (roleId)
            {
                case 1:
                    return "Администратор";
                case 2:
                    return "Начальник ОТК";
                case 3:
                    return "Работник ОТК";
                default:
                    throw new ArgumentException("Неизвестный уровень доступа");
            }
        }

    }
}
