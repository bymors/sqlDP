﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sqlDiplome
{
    public partial class Form1 : Form
    {
        private string _userRole;
        public Form1(string userRole)
        {
            InitializeComponent();
            _userRole = userRole;
            UIchoicerole();
        }

        private void UIchoicerole()
        {
            switch (_userRole)
            {
                case "Администратор": 
                    
                    break;

                case "Начальник ОТК":
                    резервноеКопированиеToolStripMenuItem.Visible = false;
                    учетнаяЗаписьToolStripMenuItem.Visible=false;
                    break;

                case "Работник ОТК":
                    резервноеКопированиеToolStripMenuItem.Visible = false;
                    учетнаяЗаписьToolStripMenuItem.Visible=false;
                    отчетыToolStripMenuItem.Visible = false;
                    ПоискToolStripMenuItem1.Visible = false;
                    сотрудникиToolStripMenuItem1.Visible = false;
                    сотрудникиToolStripMenuItem.Visible = false;
                    break;

                default:
                    MessageBox.Show("Неизвестная роль пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void оборудованиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.Oborydovanie.ReadTable();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.Sotrydniki.ReadTable();
        }

        private void тестыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.Test.ReadTable();
        }

        private void испытанияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.Ispitanie.ReadTable();
        }

        private void выборToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.Vibor.ReadTable();
        }

        private void оборудованиеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Oboryd vklform = new Oboryd("", "", "", "", "", _userRole);
            vklform.Show();
        }

        private void сотрудникиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Sotrydniki vklform = new Sotrydniki("", "", "", "", "", _userRole);
            vklform.Show();
        }

        private void тестыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Testu vklform = new Testu("", "", "", _userRole);
            vklform.Show();
        }

        private void испытанияToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Ispitanie vklform = new Ispitanie("", "", "", "", "", _userRole);
            vklform.Show();
        }

        private void выборToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Vibor vklform = new Vibor("", "", "", _userRole);
            vklform.Show();
        }

        private void поискПоОборудованиюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Poisk vklform = new Poisk("Oboryd", 5, _userRole);
            vklform.Show();
        }

        private void поискПоСотрудниковToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Poisk vklform = new Poisk("Sotrydniki", 5, _userRole);
            vklform.Show();
        }

        private void поикToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Poisk vklform = new Poisk("Testu", 3, _userRole);
            vklform.Show();
        }

        private void поискПоИспытаниямToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Poisk vklform = new Poisk("Ispitanie", 5, _userRole);
            vklform.Show();
        }

        private void поискПоВыборуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Poisk vklform = new Poisk("Vibor", 3, _userRole);
            vklform.Show();
        }

        private void отчетПоИспытаниямToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OtchetPoISP vklform = new OtchetPoISP();
            vklform.Show();
        }

        private void отчетПоСотрудникамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OtchetPoSOTR vklform = new OtchetPoSOTR();
            vklform.Show();
        }

        private void отчетПоТестамToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OtchetPoTEST vklform = new OtchetPoTEST();
            vklform.Show();
        }

        private void просмотрУчетныхЗаписейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ObshiuClass.YchetnaiaZapis.ReadTable();
        }

        private void добавитьУчетнуюЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YchetnaiaZapis vklform = new YchetnaiaZapis("","","", _userRole);
            vklform.Show();
        }

        private void резервноеКопированиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Backup vklform = new Backup();
            vklform.Show();
        }
    }
}
