﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sqlDiplome
{
    public partial class LoginAuth : Form
    {
        public string UserRole { get; private set; }

        public LoginAuth()
        {
            InitializeComponent();
        }
        public class Role
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public int Roole { get; set; }
        }
        public static string HashPassword(string password)
        {
            using (var md5 = MD5.Create())
            {
                var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(password));

                return Convert.ToBase64String(hash);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            Role user = regUser(username, password);

            if (user != null)
            {
                //если пароль правильный, сохр роль и закрываем форму
                UserRole = RoleName(user.Roole);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Role regUser(string username, string password)
        {
            SqlConnection connection = DBConnect.GetConnection();
            
             try
             {
                string query = "SELECT Users, Password, LvlDostyp FROM [User] WHERE Users = @Users";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Users", username);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    string storedPasswordHash = reader["Password"].ToString();
                    string inputPasswordHash = HashPassword(password);
                    if (storedPasswordHash == inputPasswordHash)
                    {
                        return new Role
                        {
                            Username = reader["Users"].ToString(),
                            Password = storedPasswordHash, // возврат хэша
                            Roole = Convert.ToInt32(reader["LvlDostyp"])
                        };
                    }
                }

                if (reader.Read())
                {
                    return new Role
                    {
                        Username = reader["Users"].ToString(),
                        Password = reader["Password"].ToString(),
                        Roole = Convert.ToInt32(reader["LvlDostyp"])
                    };
                }
             }
            catch
            {
                    
            }

            return null; 
        }
        private string RoleName(int role)
        {
            switch (role)
            {
                case 1: return "Администратор";
                case 2: return "Начальник ОТК";
                case 3: return "Работник ОТК";
                default: return "Неизвестная роль";
            }
        }
    }
}
