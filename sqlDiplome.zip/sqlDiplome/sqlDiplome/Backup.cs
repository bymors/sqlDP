﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace sqlDiplome
{
    public partial class Backup : Form
    {
        SqlConnection connection = DBConnect.GetConnection();
        private string DBName = "Diplom";
        private string backupFolder = @"C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\Backup";
        private System.Timers.Timer backupTimer;

        string backupfile;
        string backuppath;


        public Backup()
        {
            InitializeComponent();
            backupTimer = new System.Timers.Timer(24 * 60 * 60 * 1000); // 24 часа в миллисекундах
            backupTimer.Elapsed += BackupTimer_Elapsed;
            backupTimer.AutoReset = true;
            backupTimer.Enabled = true;
        }

        private void BackupTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Создание резервной копии
            backupfile = $"{DBName}_Backup_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.bak";
            backuppath = Path.Combine(backupFolder, backupfile);
            CreateBackup(backuppath);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            backupfile = $"{DBName}_Backup_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.bak";
            backuppath = Path.Combine(backupFolder, backupfile);

            CreateBackup(backuppath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = backupFolder,
                Filter = "Backup files (*.bak)|*.bak",
                Title = "Выберите резервную копию для восстановления"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                backuppath = openFileDialog.FileName;

                DialogResult result = MessageBox.Show(
                    "Вы действительно хотите восстановить базу данных? Это приведет к потере текущих данных.",
                    "Подтверждение восстановления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    RestoreDatabase(backuppath);
                }
            }
        }

        private void CreateBackup(string backupPath)
        {
            try
            {
                string query = $"BACKUP DATABASE [{DBName}] TO DISK = '{backupPath}'";

                SqlCommand command = new SqlCommand(query, connection);
                    command.ExecuteNonQuery();
                MessageBox.Show($"Резервная копия создана: {backupPath}", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании резервной копии: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void RestoreDatabase(string backupPath)
        {
            try
            {
                string useMasterQuery = "USE master";
                using (SqlCommand useMasterCommand = new SqlCommand(useMasterQuery, connection))
                {
                    useMasterCommand.ExecuteNonQuery();
                }

                string setSingleUserQuery = $"ALTER DATABASE [{DBName}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE";
                using (SqlCommand setSingleUserCommand = new SqlCommand(setSingleUserQuery, connection))
                {
                    setSingleUserCommand.ExecuteNonQuery();
                }

                string restoreQuery = $"RESTORE DATABASE [{DBName}] FROM DISK = '{backupPath}' WITH REPLACE";
                using (SqlCommand restoreCommand = new SqlCommand(restoreQuery, connection))
                {
                    restoreCommand.ExecuteNonQuery();
                }

                string setMultiUserQuery = $"ALTER DATABASE [{DBName}] SET MULTI_USER";
                using (SqlCommand setMultiUserCommand = new SqlCommand(setMultiUserQuery, connection))
                {
                    setMultiUserCommand.ExecuteNonQuery();
                }

                MessageBox.Show("База данных восстановлена", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при восстановлении базы данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                    connection.Close();
                
            }
        }
    }
}
