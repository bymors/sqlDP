﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace sqlDiplome
{
    public partial class OtchetPoTEST : Form
    {
        public OtchetPoTEST()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            try
            {

                string query = $@"SELECT T.Name_T AS test_name, T.Opisanie_T AS test_opisanie, 
                COUNT(V.ID_ispitanie) AS isp_count
                FROM Testu T LEFT JOIN Vibor V ON T.ID_test = V.ID_test 
                GROUP BY T.ID_test, T.Name_T, T.Opisanie_T ORDER BY isp_count DESC;";

                SqlDataAdapter command = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();
                command.Fill(table);
                dataGridView1.DataSource = table;
                button2.Visible = true;
            }
            catch
            {
                MessageBox.Show("Ошибка запроса");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = null;
            Excel.Worksheet xlSheet = null;
            Excel.Range xlSheetRange = null;

            try
            {
                xlApp = new Excel.Application();
                xlApp.Visible = false;

                Excel.Workbook xlWorkbook = xlApp.Workbooks.Add(Type.Missing);
                xlSheet = (Excel.Worksheet)xlWorkbook.Sheets[1];
                xlSheet.Name = "Данные";

                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    xlSheet.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
                }

                for (int rowInd = 0; rowInd < dataGridView1.Rows.Count; rowInd++)
                {
                    if (dataGridView1.Rows[rowInd].IsNewRow) continue;

                    for (int collInd = 0; collInd < dataGridView1.Columns.Count; collInd++)
                    {
                        xlSheet.Cells[rowInd + 2, collInd + 1] = dataGridView1.Rows[rowInd].Cells[collInd].Value?.ToString();
                    }
                }

                Excel.Range columnA = xlSheet.Columns["A:A"];
                columnA.ColumnWidth = 25;
                Excel.Range columnB = xlSheet.Columns["B:B"];
                columnB.ColumnWidth = 100;
                Excel.Range columnC = xlSheet.Columns["C:C"];
                columnC.ColumnWidth = 25;

                xlSheetRange = xlSheet.UsedRange;
                xlSheetRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                xlSheetRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = "Отчет_по_тестам.xlsx"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    xlWorkbook.SaveAs(saveFileDialog.FileName);
                    MessageBox.Show("Отчет сохранен", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании отчета: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (xlApp != null)
                {
                    xlApp.Quit();
                    releaseObject(xlSheetRange);
                    releaseObject(xlSheet);
                    releaseObject(xlApp);
                }
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Ошибка при освобождении ресурсов: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
