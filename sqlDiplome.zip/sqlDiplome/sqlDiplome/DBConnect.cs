﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sqlDiplome
{
    internal class DBConnect
    {
        private static string connectionString = "Server=DESKTOP-MTE083Q\\SQLEXPRESS;Database=Diplom;Trusted_Connection=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
            }
            catch (Exception erorr)
            {
                Console.WriteLine("Ошибка при подключении к базе данных: " + erorr.Message);
            }
            return connection;
        }
    }
}
