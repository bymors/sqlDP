﻿namespace sqlDiplome
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.просмотрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оборудованиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тестыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.испытанияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выборToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.данныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оборудованиеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.тестыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.испытанияToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выборToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ПоискToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поискПоОборудованиюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поискПоСотрудниковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поикToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поискПоИспытаниямToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поискПоВыборуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетПоИспытаниямToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетПоСотрудникамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетПоТестамToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.учетнаяЗаписьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.просмотрУчетныхЗаписейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьУчетнуюЗаписьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.резервноеКопированиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.просмотрToolStripMenuItem,
            this.данныеToolStripMenuItem,
            this.ПоискToolStripMenuItem1,
            this.отчетыToolStripMenuItem,
            this.учетнаяЗаписьToolStripMenuItem,
            this.резервноеКопированиеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(898, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // просмотрToolStripMenuItem
            // 
            this.просмотрToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оборудованиеToolStripMenuItem,
            this.сотрудникиToolStripMenuItem,
            this.тестыToolStripMenuItem,
            this.испытанияToolStripMenuItem,
            this.выборToolStripMenuItem});
            this.просмотрToolStripMenuItem.Name = "просмотрToolStripMenuItem";
            this.просмотрToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.просмотрToolStripMenuItem.Text = "Просмотр";
            // 
            // оборудованиеToolStripMenuItem
            // 
            this.оборудованиеToolStripMenuItem.Name = "оборудованиеToolStripMenuItem";
            this.оборудованиеToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.оборудованиеToolStripMenuItem.Text = "Оборудование";
            this.оборудованиеToolStripMenuItem.Click += new System.EventHandler(this.оборудованиеToolStripMenuItem_Click);
            // 
            // сотрудникиToolStripMenuItem
            // 
            this.сотрудникиToolStripMenuItem.Name = "сотрудникиToolStripMenuItem";
            this.сотрудникиToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.сотрудникиToolStripMenuItem.Text = "Сотрудники";
            this.сотрудникиToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem_Click);
            // 
            // тестыToolStripMenuItem
            // 
            this.тестыToolStripMenuItem.Name = "тестыToolStripMenuItem";
            this.тестыToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.тестыToolStripMenuItem.Text = "Тесты";
            this.тестыToolStripMenuItem.Click += new System.EventHandler(this.тестыToolStripMenuItem_Click);
            // 
            // испытанияToolStripMenuItem
            // 
            this.испытанияToolStripMenuItem.Name = "испытанияToolStripMenuItem";
            this.испытанияToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.испытанияToolStripMenuItem.Text = "Испытания";
            this.испытанияToolStripMenuItem.Click += new System.EventHandler(this.испытанияToolStripMenuItem_Click);
            // 
            // выборToolStripMenuItem
            // 
            this.выборToolStripMenuItem.Name = "выборToolStripMenuItem";
            this.выборToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.выборToolStripMenuItem.Text = "Выбор";
            this.выборToolStripMenuItem.Click += new System.EventHandler(this.выборToolStripMenuItem_Click);
            // 
            // данныеToolStripMenuItem
            // 
            this.данныеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оборудованиеToolStripMenuItem1,
            this.сотрудникиToolStripMenuItem1,
            this.тестыToolStripMenuItem1,
            this.испытанияToolStripMenuItem1,
            this.выборToolStripMenuItem1});
            this.данныеToolStripMenuItem.Name = "данныеToolStripMenuItem";
            this.данныеToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.данныеToolStripMenuItem.Text = "Данные";
            // 
            // оборудованиеToolStripMenuItem1
            // 
            this.оборудованиеToolStripMenuItem1.Name = "оборудованиеToolStripMenuItem1";
            this.оборудованиеToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.оборудованиеToolStripMenuItem1.Text = "Оборудование";
            this.оборудованиеToolStripMenuItem1.Click += new System.EventHandler(this.оборудованиеToolStripMenuItem1_Click);
            // 
            // сотрудникиToolStripMenuItem1
            // 
            this.сотрудникиToolStripMenuItem1.Name = "сотрудникиToolStripMenuItem1";
            this.сотрудникиToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.сотрудникиToolStripMenuItem1.Text = "Сотрудники";
            this.сотрудникиToolStripMenuItem1.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem1_Click);
            // 
            // тестыToolStripMenuItem1
            // 
            this.тестыToolStripMenuItem1.Name = "тестыToolStripMenuItem1";
            this.тестыToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.тестыToolStripMenuItem1.Text = "Тесты";
            this.тестыToolStripMenuItem1.Click += new System.EventHandler(this.тестыToolStripMenuItem1_Click);
            // 
            // испытанияToolStripMenuItem1
            // 
            this.испытанияToolStripMenuItem1.Name = "испытанияToolStripMenuItem1";
            this.испытанияToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.испытанияToolStripMenuItem1.Text = "Испытания";
            this.испытанияToolStripMenuItem1.Click += new System.EventHandler(this.испытанияToolStripMenuItem1_Click);
            // 
            // выборToolStripMenuItem1
            // 
            this.выборToolStripMenuItem1.Name = "выборToolStripMenuItem1";
            this.выборToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.выборToolStripMenuItem1.Text = "Выбор";
            this.выборToolStripMenuItem1.Click += new System.EventHandler(this.выборToolStripMenuItem1_Click);
            // 
            // ПоискToolStripMenuItem1
            // 
            this.ПоискToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поискПоОборудованиюToolStripMenuItem,
            this.поискПоСотрудниковToolStripMenuItem,
            this.поикToolStripMenuItem,
            this.поискПоИспытаниямToolStripMenuItem,
            this.поискПоВыборуToolStripMenuItem});
            this.ПоискToolStripMenuItem1.Name = "ПоискToolStripMenuItem1";
            this.ПоискToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.ПоискToolStripMenuItem1.Text = "Поиск";
            // 
            // поискПоОборудованиюToolStripMenuItem
            // 
            this.поискПоОборудованиюToolStripMenuItem.Name = "поискПоОборудованиюToolStripMenuItem";
            this.поискПоОборудованиюToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.поискПоОборудованиюToolStripMenuItem.Text = "Поиск по оборудованию";
            this.поискПоОборудованиюToolStripMenuItem.Click += new System.EventHandler(this.поискПоОборудованиюToolStripMenuItem_Click);
            // 
            // поискПоСотрудниковToolStripMenuItem
            // 
            this.поискПоСотрудниковToolStripMenuItem.Name = "поискПоСотрудниковToolStripMenuItem";
            this.поискПоСотрудниковToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.поискПоСотрудниковToolStripMenuItem.Text = "Поиск по сотрудников";
            this.поискПоСотрудниковToolStripMenuItem.Click += new System.EventHandler(this.поискПоСотрудниковToolStripMenuItem_Click);
            // 
            // поикToolStripMenuItem
            // 
            this.поикToolStripMenuItem.Name = "поикToolStripMenuItem";
            this.поикToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.поикToolStripMenuItem.Text = "Поиск по тестам";
            this.поикToolStripMenuItem.Click += new System.EventHandler(this.поикToolStripMenuItem_Click);
            // 
            // поискПоИспытаниямToolStripMenuItem
            // 
            this.поискПоИспытаниямToolStripMenuItem.Name = "поискПоИспытаниямToolStripMenuItem";
            this.поискПоИспытаниямToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.поискПоИспытаниямToolStripMenuItem.Text = "Поиск по испытаниям";
            this.поискПоИспытаниямToolStripMenuItem.Click += new System.EventHandler(this.поискПоИспытаниямToolStripMenuItem_Click);
            // 
            // поискПоВыборуToolStripMenuItem
            // 
            this.поискПоВыборуToolStripMenuItem.Name = "поискПоВыборуToolStripMenuItem";
            this.поискПоВыборуToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.поискПоВыборуToolStripMenuItem.Text = "Поиск по выбору";
            this.поискПоВыборуToolStripMenuItem.Click += new System.EventHandler(this.поискПоВыборуToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отчетПоИспытаниямToolStripMenuItem,
            this.отчетПоСотрудникамToolStripMenuItem,
            this.отчетПоТестамToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // отчетПоИспытаниямToolStripMenuItem
            // 
            this.отчетПоИспытаниямToolStripMenuItem.Name = "отчетПоИспытаниямToolStripMenuItem";
            this.отчетПоИспытаниямToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.отчетПоИспытаниямToolStripMenuItem.Text = "Отчет по Испытаниям";
            this.отчетПоИспытаниямToolStripMenuItem.Click += new System.EventHandler(this.отчетПоИспытаниямToolStripMenuItem_Click);
            // 
            // отчетПоСотрудникамToolStripMenuItem
            // 
            this.отчетПоСотрудникамToolStripMenuItem.Name = "отчетПоСотрудникамToolStripMenuItem";
            this.отчетПоСотрудникамToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.отчетПоСотрудникамToolStripMenuItem.Text = "Отчет по Сотрудникам";
            this.отчетПоСотрудникамToolStripMenuItem.Click += new System.EventHandler(this.отчетПоСотрудникамToolStripMenuItem_Click);
            // 
            // отчетПоТестамToolStripMenuItem
            // 
            this.отчетПоТестамToolStripMenuItem.Name = "отчетПоТестамToolStripMenuItem";
            this.отчетПоТестамToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.отчетПоТестамToolStripMenuItem.Text = "Отчет по Тестам";
            this.отчетПоТестамToolStripMenuItem.Click += new System.EventHandler(this.отчетПоТестамToolStripMenuItem_Click);
            // 
            // учетнаяЗаписьToolStripMenuItem
            // 
            this.учетнаяЗаписьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.просмотрУчетныхЗаписейToolStripMenuItem,
            this.добавитьУчетнуюЗаписьToolStripMenuItem});
            this.учетнаяЗаписьToolStripMenuItem.Name = "учетнаяЗаписьToolStripMenuItem";
            this.учетнаяЗаписьToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.учетнаяЗаписьToolStripMenuItem.Text = "Учетная запись ";
            // 
            // просмотрУчетныхЗаписейToolStripMenuItem
            // 
            this.просмотрУчетныхЗаписейToolStripMenuItem.Name = "просмотрУчетныхЗаписейToolStripMenuItem";
            this.просмотрУчетныхЗаписейToolStripMenuItem.Size = new System.Drawing.Size(255, 22);
            this.просмотрУчетныхЗаписейToolStripMenuItem.Text = "Просмотр учетных записей";
            this.просмотрУчетныхЗаписейToolStripMenuItem.Click += new System.EventHandler(this.просмотрУчетныхЗаписейToolStripMenuItem_Click);
            // 
            // добавитьУчетнуюЗаписьToolStripMenuItem
            // 
            this.добавитьУчетнуюЗаписьToolStripMenuItem.Name = "добавитьУчетнуюЗаписьToolStripMenuItem";
            this.добавитьУчетнуюЗаписьToolStripMenuItem.Size = new System.Drawing.Size(255, 22);
            this.добавитьУчетнуюЗаписьToolStripMenuItem.Text = "Управление учетными записями";
            this.добавитьУчетнуюЗаписьToolStripMenuItem.Click += new System.EventHandler(this.добавитьУчетнуюЗаписьToolStripMenuItem_Click);
            // 
            // резервноеКопированиеToolStripMenuItem
            // 
            this.резервноеКопированиеToolStripMenuItem.Name = "резервноеКопированиеToolStripMenuItem";
            this.резервноеКопированиеToolStripMenuItem.Size = new System.Drawing.Size(152, 20);
            this.резервноеКопированиеToolStripMenuItem.Text = "Резервное копирование";
            this.резервноеКопированиеToolStripMenuItem.Click += new System.EventHandler(this.резервноеКопированиеToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 26);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(873, 398);
            this.dataGridView1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 436);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Тестирование";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem просмотрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem данныеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ПоискToolStripMenuItem1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem оборудованиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тестыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem испытанияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выборToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оборудованиеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem тестыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem испытанияToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выборToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поискПоОборудованиюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поискПоСотрудниковToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поикToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поискПоИспытаниямToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поискПоВыборуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетПоИспытаниямToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетПоСотрудникамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетПоТестамToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem учетнаяЗаписьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem просмотрУчетныхЗаписейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьУчетнуюЗаписьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem резервноеКопированиеToolStripMenuItem;
    }
}

