﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sqlDiplome
{
    public class ObshiuClass
    {
        public class Oborydovanie
        {
            public string ID_Oboryd { get; set; }
            public string Nazvanie { get; set; }
            public string SerialNumber { get; set; }
            public string DatePrivoz { get; set; }
            public bool Garantia { get; set; }

            static public List<Oborydovanie> ReadTable()
            {
                List<Oborydovanie> res = new List<Oborydovanie>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM Oboryd";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new Oborydovanie
                        {
                            ID_Oboryd = reader[0].ToString(),
                            Nazvanie = reader[1].ToString(),
                            SerialNumber = reader[2].ToString(),
                            DatePrivoz = reader[3].ToString(),
                            Garantia = Convert.ToBoolean(reader[4])
                        });
                    }
                }
                return res;
            }

        }

        public class Sotrydniki
        {
            public string ID_Sotryd { get; set; }
            public string FIO { get; set; }
            public string Telephone { get; set; }
            public string Email { get; set; }
            public string Dolwnost { get; set; }

            static public List<Sotrydniki> ReadTable()
            {
                List<Sotrydniki> res = new List<Sotrydniki>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM Sotrydniki";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new Sotrydniki
                        {
                            ID_Sotryd = reader[0].ToString(),
                            FIO = reader[1].ToString(),
                            Telephone = reader[2].ToString(),
                            Email = reader[3].ToString(),
                            Dolwnost = reader[4].ToString()
                        });
                    }
                }
                return res;
            }
        }

        public class Test
        {
            public string ID_Test { get; set; }
            public string Name_Testa { get; set; }
            public string Opisanie_Testa { get; set; }

            static public List<Test> ReadTable()
            {
                List<Test> res = new List<Test>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM Testu";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new Test
                        {
                            ID_Test = reader[0].ToString(),
                            Name_Testa = reader[1].ToString(),
                            Opisanie_Testa = reader[2].ToString()
                        });
                    }
                }
                return res;
            }

        }

        public class Ispitanie
        {
            public string ID_Ispitanie { get; set; }
            public string ID_Oboryd { get; set; }
            public string ID_Sotryd { get; set; }
            public string DateIspitanie { get; set; }
            public string ResultIspitanie { get; set; }

            static public List<Ispitanie> ReadTable()
            {
                List<Ispitanie> res = new List<Ispitanie>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM Ispitanie";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new Ispitanie
                        {
                            ID_Ispitanie = reader[0].ToString(),
                            ID_Oboryd = reader[1].ToString(),
                            ID_Sotryd = reader[2].ToString(),
                            DateIspitanie = reader[3].ToString(),
                            ResultIspitanie = reader[4].ToString()
                        });
                    }
                }
                return res;
            }
        }

        public class Vibor
        {
            public string ID_Vibor { get; set; }
            public string ID_Test { get; set; }
            public string ID_Ispitanie { get; set; }

            static public List<Vibor> ReadTable()
            {
                List<Vibor> res = new List<Vibor>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM Vibor";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new Vibor
                        {
                            ID_Vibor = reader[0].ToString(),
                            ID_Test = reader[1].ToString(),
                            ID_Ispitanie = reader[2].ToString()
                        });
                    }
                }
                return res;
            }
        }

        public class YchetnaiaZapis
        {
            public string Login { get; set; }
            public string Password { get; set; }
            public string LvlDostyp { get; set; }

            static public List<YchetnaiaZapis> ReadTable()
            {
                List<YchetnaiaZapis> res = new List<YchetnaiaZapis>();
                using (SqlConnection connection = DBConnect.GetConnection())
                {
                    string query = "SELECT * FROM [User]";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res.Add(new YchetnaiaZapis
                        {
                            Login = reader[0].ToString(),
                            Password = reader[1].ToString(),
                            LvlDostyp = reader[2].ToString()
                        });
                    }
                }
                return res;
            }
        }



    }
}
