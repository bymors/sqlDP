﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sqlDiplome
{
    public partial class Poisk : Form
    {
        string poisk;
        int a;
        private string _userRole;
        public Poisk(string poiskGlobal, int aGlobal, string userRole )
        {
            InitializeComponent();
            poisk = poiskGlobal;
            a = aGlobal;
            _userRole = userRole;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string localPoisk = comboBox1.Text;
            string localA = textBox1.Text;
            bool b = false;

            if ((String.IsNullOrEmpty(localPoisk)) || (String.IsNullOrEmpty(localA)))
            {
                b = true;
            }

            if (!b)
            {
                samPoisk(localPoisk, localA);
            }
        }

        private void samPoisk(string lp, string la)
        {
            SqlConnection connection = DBConnect.GetConnection();
            string[] f = new string[10];

            try
            {
                string query = $"SELECT * FROM {poisk} WHERE {lp} = '{la}'";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    for (int i = 0; i < a; i++)
                    {
                        f[i] = reader[i].ToString();
                    }
                }
                if (poisk == "Oboryd")
                {
                    Oboryd psk = new Oboryd(f[0], f[1], f[2], f[3], f[4], _userRole);
                    psk.Show(); 
                }
                if (poisk == "Sotrydniki")
                {
                    Sotrydniki psk = new Sotrydniki(f[0], f[1], f[2], f[3], f[4], _userRole);
                    psk.Show();
                    this.Close();
                }
                if (poisk == "Ispitanie")
                {
                    Ispitanie psk = new Ispitanie(f[0], f[1], f[2], f[3], f[4], _userRole);
                    psk.Show();
                    this.Close();
                }
                if (poisk == "Vibor")
                {
                    Vibor psk = new Vibor(f[0], f[1], f[2], _userRole);
                    psk.Show();
                    this.Close();
                }
                if (poisk == "Testu")
                {
                    Testu psk = new Testu(f[0], f[1], f[2], _userRole);
                    psk.Show();
                    this.Close();
                }

            }

            catch
            {
                MessageBox.Show("Данные не найдены");
            }
            finally
            {
                connection.Close();
            }
        }

        private void Poisk_Load(object sender, EventArgs e)
        {
            if (poisk == "Oboryd")
            {
                List<string> itemlist = new List<string>() { "ID_oboryd", "Nazvanie", "SerialNumber", "Date_privoz", "Garantia" };
                comboBox1.Items.AddRange(itemlist.ToArray());
            }
            if (poisk == "Sotrydniki")
            {
                List<string> itemlist = new List<string>() { "ID_sotryd", "FIO", "Telephone", "Email", "Dolwnost" };
                comboBox1.Items.AddRange(itemlist.ToArray());
            }
            if (poisk == "Ispitanie")
            {
                List<string> itemlist = new List<string>() { "ID_ispitanie", "ID_oboryd", "ID_sotryd", "Date_ispitanie", "Result_ISP" };
                comboBox1.Items.AddRange(itemlist.ToArray());
            }
            if (poisk == "Vibor")
            {
                List<string> itemlist = new List<string>() { "ID_Vibor", "ID_test", "ID_ispitanie" };
                comboBox1.Items.AddRange(itemlist.ToArray());
            }
            if (poisk == "Testu")
            {
                List<string> itemlist = new List<string>() { "ID_test", "Name_T", "Opisanie_T" };
                comboBox1.Items.AddRange(itemlist.ToArray());
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || (e.KeyChar >= 'а' && e.KeyChar <= 'я') || (e.KeyChar >= 'А' && e.KeyChar <= 'Я') && e.KeyChar != 'ё' && e.KeyChar != 'Ё' || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == ' ')))
            {
                e.Handled = true;
            }
        }
    }
}
