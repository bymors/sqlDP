﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sqlDiplome
{
    public partial class Testu : Form
    {
        string[] str = new string[4];
        private string _userRole;
        public Testu(string p1, string p2, string p3, string userRole)
        {
            InitializeComponent();
            str[0] = p1;
            str[1] = p2;
            str[2] = p3;
            _userRole = userRole;
            UIchoiceRole();
        }
        private void UIchoiceRole()
        {
            switch (_userRole)
            {
                case "Администратор":

                    break;

                case "Начальник ОТК":

                    break;

                case "Работник ОТК":
                    button2.Visible = false;
                    break;

                default:
                    MessageBox.Show("Неизвестная роль пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("Поля не должны быть пустыми");
                return;
            }

            try
            {

                string query = $"INSERT INTO Testu (ID_test, Name_T, Opisanie_T)" +
                $"VALUES(@value1, @value2, @value3)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@value1", textBox1.Text);
                command.Parameters.AddWithValue("@value2", textBox2.Text);
                command.Parameters.AddWithValue("@value3", textBox3.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные сохранены");
            }
            catch
            {

                DialogResult result = MessageBox.Show("Запись с таким кодом уже есть. Перезаписать данные?", "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.None,
                    MessageBoxDefaultButton.Button1);

                if (result == DialogResult.Yes)
                {
                    string query = $"UPDATE Testu SET Name_T = @value2, Opisanie_T = @value3 " +
                    $" WHERE ID_test = @value1";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@value1", textBox1.Text);
                    command.Parameters.AddWithValue("@value2", textBox2.Text);
                    command.Parameters.AddWithValue("@value3", textBox3.Text);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные изменены");
                }
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();


            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                if (!String.IsNullOrEmpty(textBox1.Text))
                {
                    try
                    {
                        string query = $"DELETE FROM Testu WHERE ID_test = {textBox1.Text}";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные удалены");

                    }
                    catch
                    {

                    }
                }
                else { MessageBox.Show("Данные не изменились"); }

            }
            else { MessageBox.Show("Введите id test"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                try
                {
                    string query = $"SELECT * FROM Testu WHERE ID_test = {textBox1.Text}";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        textBox1.Text = reader[0].ToString();
                        textBox2.Text = reader[1].ToString();
                        textBox3.Text = reader[2].ToString();
                    }
                    else { MessageBox.Show("Данные не найдены"); }

                }
                catch
                {

                }

            }
            else { MessageBox.Show("Введите id test"); }
        }

        private void Testu_Shown(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            if (!String.IsNullOrEmpty(str[0]))
            {

                textBox1.Text = str[0];
                textBox2.Text = str[1];
                textBox3.Text = str[2];

            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && e.KeyChar != ' ' && (e.KeyChar < 'А' || e.KeyChar > 'я') && e.KeyChar != 'ё' && e.KeyChar != 'Ё')
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && e.KeyChar != ' ' && (e.KeyChar < 'А' || e.KeyChar > 'я') && e.KeyChar != 'ё' && e.KeyChar != 'Ё')
            {
                e.Handled = true;
            }
        }
    }
}
