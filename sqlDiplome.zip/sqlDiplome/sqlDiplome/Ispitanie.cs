﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sqlDiplome
{
    public partial class Ispitanie : Form
    {
        string[] str = new string[6];
        private string _userRole;
        public Ispitanie(string p1, string p2, string p3, string p4, string p5, string userRole)
        {
            InitializeComponent();
            str[0] = p1;
            str[1] = p2;
            str[2] = p3;
            str[3] = p4;
            str[4] = p5;
            _userRole = userRole;
            UIchoiceRole();
        }

        private void UIchoiceRole()
        {
            switch (_userRole)
            {
                case "Администратор":

                    break;

                case "Начальник ОТК":

                    break;

                case "Работник ОТК":
                    button2.Visible = false;
                    break;

                default:
                    MessageBox.Show("Неизвестная роль пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(comboBox2.Text) || string.IsNullOrEmpty(comboBox3.Text))
            {
                MessageBox.Show("Поля не должны быть пустыми");
                return;
            }

            try
            {

                string query = $"INSERT INTO Ispitanie (ID_ispitanie, ID_oboryd, ID_sotryd, Date_ispitanie, Result_ISP)" +
                $"VALUES(@value1, @value2, @value3, @value4, @value5)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@value1", textBox1.Text);
                command.Parameters.AddWithValue("@value2", comboBox2.Text);
                command.Parameters.AddWithValue("@value3", comboBox3.Text);
                command.Parameters.AddWithValue("@value4", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("@value5", comboBox4.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Данные сохранены");
            }
            catch
            {

                DialogResult result = MessageBox.Show("Запись с таким кодом уже есть. Перезаписать данные?", "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.None,
                    MessageBoxDefaultButton.Button1);

                if (result == DialogResult.Yes)
                {
                    string query = $"UPDATE Ispitanie SET ID_oboryd = @value2, ID_sotryd = @value3, Date_ispitanie = @value4, Result_ISP = @value5" +
                    $" WHERE ID_ispitanie = @value1";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@value1", textBox1.Text);
                    command.Parameters.AddWithValue("@value2", comboBox2.Text);
                    command.Parameters.AddWithValue("@value3", comboBox3.Text);
                    command.Parameters.AddWithValue("@value4", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@value5", comboBox4.Text);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные изменены");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();


            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                if (!String.IsNullOrEmpty(textBox1.Text))
                {
                    try
                    {
                        string query = $"DELETE FROM Ispitanie WHERE ID_ispitanie = {textBox1.Text}";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные удалены");

                    }
                    catch
                    {

                    }
                }
                else { MessageBox.Show("Данные не изменились"); }

            }
            else { MessageBox.Show("Введите id ispitanie"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnect.GetConnection();

            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                try
                {
                    string query = $"SELECT * FROM Ispitanie WHERE ID_ispitanie = {textBox1.Text}";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        textBox1.Text = reader[0].ToString();
                        comboBox2.Text = reader[1].ToString();
                        comboBox3.Text = reader[2].ToString();
                        dateTimePicker1.Text = reader[3].ToString();
                        comboBox4.Text = reader[4].ToString();
                    }
                    else { MessageBox.Show("Данные не найдены"); }

                }
                catch
                {

                }

            }
            else { MessageBox.Show("Введите id ispitanie"); }
        }

        private void Ispitanie_Shown(object sender, EventArgs e)
        {
            textBox1.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            comboBox4.Items.Clear();
            comboBox4.Items.Add("Успешно");
            comboBox4.Items.Add("Неудачно");
            comboBox4.Items.Add("Нужны дополнительное тестирование");

            if (!String.IsNullOrEmpty(str[0]))
            {

                textBox1.Text = str[0];
                comboBox2.Text = str[1];
                comboBox3.Text = str[2];
                if (DateTime.TryParse(str[3], out DateTime parsedDate1))
                {
                    dateTimePicker1.Value = parsedDate1;
                }
                else
                {
                    MessageBox.Show("Ошибка");
                }
                comboBox4.Text = str[4];
            }

            SqlConnection connection = DBConnect.GetConnection();

            string st = $"SELECT ID_oboryd FROM Oboryd";
            SqlCommand command = new SqlCommand(st, connection);
            SqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr[0]);
            }

            connection.Close();

            SqlConnection connection1 = DBConnect.GetConnection();

            string st1 = $"SELECT ID_sotryd FROM Sotrydniki";
            SqlCommand command1 = new SqlCommand(st1, connection1);
            SqlDataReader dr1 = command1.ExecuteReader();
            while (dr1.Read())
            {
                comboBox3.Items.Add(dr1[0]);
            }

            connection1.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
